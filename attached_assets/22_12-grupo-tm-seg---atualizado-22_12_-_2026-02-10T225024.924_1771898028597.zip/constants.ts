

// ==========================================
// VERSÃO DO SISTEMA
// ==========================================
export const APP_VERSION = "3.1.5";

// ==========================================
// CONFIGURAÇÕES DE RETENÇÃO (ESPAÇO EM BANCO)
// ==========================================
export const DATA_RETENTION = {
    LOGS_DAYS: 30,             // Manter logs por 30 dias
    BACKUP_INTERVAL_HRS: 12,   // Alerta de backup a cada 12h
    STORAGE_LIMIT_MB: 500,     // Limite do plano Free Supabase
};

// ==========================================
// CONFIGURAÇÕES DE CUSTOS ESTIMADOS (BRL)
// ==========================================
export const COST_ESTIMATES = {
    WDAPI_PER_CALL: 0.05,        // R$ 0,05 por consulta de placa
    GOOGLE_MAPS_ROUTING: 0.025,  // R$ 0,025 por calculo de rota/distância
    SUPABASE_ROW_STORAGE: 0.0001, // Estimativa por linha (armazenamento + IO)
    AI_GEMINI_FLASH: 0.01,       // Estimativa por prompt simples
    AI_GEMINI_PRO: 0.08,         // Estimativa por prompt complexo/imagem
};

// ==========================================
// CONFIGURAÇÕES DE API (WDAPI - NOVA)
// ==========================================
export const API_BRASIL_CONFIG = {
    BASE_URL: 'https://wdapi2.com.br/consulta',
    TOKEN: 'df33776079bee01ffff73467880719dd', 
    MONTHLY_LIMIT: 20000
};

// ==========================================
// CONFIGURAÇÃO API PEDÁGIO
// ==========================================
export const TOLL_API_CONFIG = {
    BASE_URL: 'https://www.calcularpedagio.com.br/api',
    API_KEY: 'c584cfb5-0c6a-4816-bfdd-3519c5bc5ef7'
};

// ==========================================
// CONFIGURAÇÃO API WHATSAPP (Z-API)
// ==========================================
export const WHATSAPP_API_CONFIG = {
    INSTANCE_ID: '3EB855234005F2ED65D1AAB367B57754', 
    TOKEN: '51F92C1F4006919C68164A03', 
    CLIENT_TOKEN: 'Faf6ccbba7fea4c3c8a75288eb27f117aS',

    get BASE_URL() {
        return `https://api.z-api.io/instances/${this.INSTANCE_ID}/token/${this.TOKEN}/send-text`;
    },
    get SEND_IMAGE_URL() {
        return `https://api.z-api.io/instances/${this.INSTANCE_ID}/token/${this.TOKEN}/send-image`;
    },
    get GROUPS_URL() {
        return `https://api.z-api.io/instances/${this.INSTANCE_ID}/token/${this.TOKEN}/groups`;
    }
};

// ==========================================
// MENU DE NAVEGAÇÃO
// ==========================================
export interface NavItem {
  name: string;
  icon: string;
  id: string;
  children?: { name: string; id: string }[];
}

export const NAV_ITEMS: NavItem[] = [
  { name: 'Página Inicial', icon: 'LayoutDashboard', id: 'dashboard' },
  { name: 'Monitoramento', icon: 'MapPin', id: 'missions' },
  { name: 'Rede de Apoio (QRF)', icon: 'Map', id: 'support-network' },
  {
    name: 'Financeiro',
    icon: 'Wallet', 
    id: 'finance-group',
    children: [
      { name: 'Dashboard Financeiro', id: 'fin-dashboard' },
      { name: 'Gestão de Cobrança', id: 'fin-billing-control' },
      { name: 'Boletim de Medição', id: 'fin-billing' },
      { name: 'Movimento Diário', id: 'fin-daily-movement' },
      { name: 'Lançamentos (Caixa)', id: 'fin-transactions' },
      { name: 'Relatório Geral (Diretoria)', id: 'fin-report' },
      { name: 'DRE Gerencial', id: 'fin-dre' },
      { name: 'Gerenciar Contas (Bancos)', id: 'fin-accounts' },
      { name: 'Categorias Financeiras', id: 'fin-categories' },
    ]
  },
  { 
    name: 'Cliente', 
    icon: 'Users', 
    id: 'clients-group',
    children: [
      { name: 'Cadastro de Cliente', id: 'clients' },
      { name: 'Gestão de Contratos', id: 'contract-manager' },
      { name: 'Cadastro de Usuário', id: 'client-users' },
      { name: 'Veículos (Carga)', id: 'client-vehicles' }, 
      { name: 'Cadastro de Rotas', id: 'client-routes' },
    ]
  },
  { 
    name: 'Fornecedor', 
    icon: 'Briefcase', 
    id: 'providers-group',
    children: [
      { name: 'Cadastro de Fornecedor', id: 'providers' },
      { name: 'Gestão de Alvarás', id: 'alvara-control' },
      { name: 'Cadastro de Usuário', id: 'provider-users' },
      { name: 'Cadastro de Viaturas', id: 'provider-vehicles' },
      { name: 'Cadastro de Agentes', id: 'provider-agents' },
      { name: 'Tecnologias (Rastreador)', id: 'provider-technologies' },
    ]
  },
  { 
    name: 'Configurações', 
    icon: 'Settings', 
    id: 'settings-group',
    children: [
      { name: 'Backup & Manutenção', id: 'db-maintenance' },
      { name: 'Otimização de Custos', id: 'cost-optimization' }, 
      { name: 'Equipe Interna', id: 'internal-users' }, 
      { name: 'Perfis de Acesso', id: 'profiles' },
      { name: 'Auditoria & Logs', id: 'system-logs' },
      { name: 'Status do Servidor', id: 'server-stats' },
    ]
  },
];
